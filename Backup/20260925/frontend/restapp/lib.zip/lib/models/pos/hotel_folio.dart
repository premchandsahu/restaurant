class HotelFolio {
  final int folioId;
  final String folioNo;

  final int stayId;
  final String stayNo;
  final String? stayStatus;

  final HotelFolioGuest guest;
  final HotelFolioRoom room;

  final String? checkIn;
  final String? expectedCheckOut;

  final String status;

  final double totalAmount;
  final double paidAmount;
  final double balanceAmount;

  final List<HotelFolioEntry> entries;

  HotelFolio({
    required this.folioId,
    required this.folioNo,
    required this.stayId,
    required this.stayNo,
    this.stayStatus,
    required this.guest,
    required this.room,
    this.checkIn,
    this.expectedCheckOut,
    required this.status,
    required this.totalAmount,
    required this.paidAmount,
    required this.balanceAmount,
    required this.entries,
  });

  factory HotelFolio.fromJson(Map<String, dynamic> json) {
    return HotelFolio(
      folioId: _toInt(json['folioId']),
      folioNo: json['folioNo']?.toString() ?? '',
      stayId: _toInt(json['stayId']),
      stayNo: json['stayNo']?.toString() ?? '',
      stayStatus: json['stayStatus']?.toString(),

      guest: HotelFolioGuest.fromJson(json['guest'] ?? {}),

      room: HotelFolioRoom.fromJson(json['room'] ?? {}),

      checkIn: json['checkIn']?.toString(),
      expectedCheckOut: json['expectedCheckOut']?.toString(),

      status: json['status']?.toString() ?? 'OPEN',

      totalAmount: _toDouble(json['totalAmount']),

      paidAmount: _toDouble(json['paidAmount']),

      balanceAmount: _toDouble(json['balanceAmount']),

      entries: (json['entries'] as List? ?? [])
          .map((e) => HotelFolioEntry.fromJson(e as Map<String, dynamic>))
          .toList(),
    );
  }
}

class HotelFolioGuest {
  final int guestId;
  final String? guestCode;
  final String? firstName;
  final String? lastName;
  final String? phone;

  HotelFolioGuest({
    required this.guestId,
    this.guestCode,
    this.firstName,
    this.lastName,
    this.phone,
  });

  String get displayName {
    return [
      firstName,
      lastName,
    ].where((e) => e != null && e!.trim().isNotEmpty).join(' ');
  }

  factory HotelFolioGuest.fromJson(Map<String, dynamic> json) {
    return HotelFolioGuest(
      guestId: _toInt(json['guestId']),
      guestCode: json['guestCode']?.toString(),
      firstName: json['firstName']?.toString(),
      lastName: json['lastName']?.toString(),
      phone: json['phone']?.toString(),
    );
  }
}

class HotelFolioRoom {
  final int roomId;
  final String? roomNo;
  final String? roomName;

  HotelFolioRoom({required this.roomId, this.roomNo, this.roomName});

  factory HotelFolioRoom.fromJson(Map<String, dynamic> json) {
    return HotelFolioRoom(
      roomId: _toInt(json['roomId']),
      roomNo: json['roomNo']?.toString(),
      roomName: json['roomName']?.toString(),
    );
  }
}

class HotelFolioEntry {
  final int folioEntryId;
  final String? entryDate;
  final String entryType;
  final String description;

  final double quantity;
  final double rate;
  final double amount;

  final String? sourceType;
  final int? sourceId;
  final int? referenceEntryId;

  final String status;
  final String? remarks;

  HotelFolioEntry({
    required this.folioEntryId,
    this.entryDate,
    required this.entryType,
    required this.description,
    required this.quantity,
    required this.rate,
    required this.amount,
    this.sourceType,
    this.sourceId,
    this.referenceEntryId,
    required this.status,
    this.remarks,
  });

  factory HotelFolioEntry.fromJson(Map<String, dynamic> json) {
    return HotelFolioEntry(
      folioEntryId: _toInt(json['folioEntryId']),

      entryDate: json['entryDate']?.toString(),

      entryType: json['entryType']?.toString() ?? 'OTHER',

      description: json['description']?.toString() ?? '',

      quantity: _toDouble(json['quantity']),

      rate: _toDouble(json['rate']),

      amount: _toDouble(json['amount']),

      sourceType: json['sourceType']?.toString(),

      sourceId: json['sourceId'] == null ? null : _toInt(json['sourceId']),

      referenceEntryId: json['referenceEntryId'] == null
          ? null
          : _toInt(json['referenceEntryId']),

      status: json['status']?.toString() ?? 'POSTED',

      remarks: json['remarks']?.toString(),
    );
  }
}

// ---------------------------------------------------------
// Helpers
// ---------------------------------------------------------

int _toInt(dynamic value) {
  if (value == null) return 0;

  if (value is int) return value;

  return int.tryParse(value.toString()) ?? 0;
}

double _toDouble(dynamic value) {
  if (value == null) return 0;

  if (value is double) return value;

  if (value is num) {
    return value.toDouble();
  }

  return double.tryParse(value.toString()) ?? 0;
}
